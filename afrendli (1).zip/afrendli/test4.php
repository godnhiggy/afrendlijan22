<?php
$afrendliMessage = $_POST["message"];
$array = $_POST["messageReceiver"];

print_r($array);

$arrlength = count($array);

for($x = 0; $x < $arrlength; $x++) {

        $useremail = $array[$x];

$to = $useremail;
$message = $msg;
$from = 'admin@coachhiggy.com';
// To send HTML mail, the Content-type header must be set
$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

// Create email headers
$headers .= 'From: '.$from."\r\n".
    'Reply-To: '.$from."\r\n" .
    'X-Mailer: PHP/' . phpversion();

if ((empty($to)) || (empty($message))) {
echo "<br>message to ".$to;
echo " will be ".$afrendliMessage;
}

//mail("$to", "Hitting the Highlights", "$message", "$headers");

}

?>
