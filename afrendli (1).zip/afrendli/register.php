<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title>afrendli register</title>
  <link rel="stylesheet" href="style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
  body {
    background-color: #2196F3; /* for browsers with no support of gradient*/
    /*background-image: linear-gradient(grey, white );*/
  }
  table {margin-left: auto;
         margin-right: auto;
       }
         .grid-container {
           display: grid;
           grid-template-columns: auto auto auto auto;
           grid-gap: 3px;
            /* background-color: #2196F3;for browsers with no support of gradient
           background-image: linear-gradient(grey, white );*/
           padding: 3px;
           justify-content: center;
           }

         .grid-container > div {
           width: 100%; /* try different value for this */
           margin: auto;
           justify-content: center;
           text-align: center;
           padding: 5px 0;
           font-size: 15px;

         }
        /* .topleft  { grid-area: 1 / 1 / 2 / 2;
                     font-size: 14px;
         }*/
         .header   { grid-area: 1 / 1 / 2 / 5;
           font: 14px Helvetica, sans-serif;
         }
        /* .logout   { grid-area: 1 / 4 / 2 / 5; }*/

         .menu     { grid-area: 2 / 1 / 3 / 5; }

         .subject  { grid-area: 3 / 1 / 4 / 5; }

         .main     { grid-area: 4 / 1 / 5 / 5; }

         .bottom     { grid-area: 5 / 1 / 6 / 5; }

         table td + td { border-left:0px solid transparent; }

         #button {
         font: 12px Helvetica, sans-serif;
         text-decoration: none;
         background-color: #EEEEEE;
         color: #333333;
         padding: 2px 6px 2px 6px;
         border-top: 1px solid #CCCCCC;
         border-right: 1px solid #333333;
         border-bottom: 1px solid #333333;
         border-left: 1px solid #CCCCCC;
         border-radius: 6px;
         }
  </style>
  </head>
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>-->
  <body>
    <div class="grid-container">
    <div class="header">
      <h2>afrendli</h2>
    </div>
    <div class="menu" id="menu">
        <a href="login.php" id="button">Need to Login?</a>

    </div>
    <div class="subject"></div>
    <div class="main">
      <form action="server.php" method="post">
        <table class="center">
          <tr>
            <td align="right"><label for="teamName"><b>Team Name</b></label></td>
            <td></td>
            <td align="left"><label for="userName"><b>Coach Name</b></label></td>
          </tr>
        <!--  <tr height="25px>">
        </tr>-->
        <tr>
          <td align="right"><input style="text-align: right" type="text" id="teamName" name="teamName" required size="10" maxlength="20"></td>
          <td align="center"><font size="5">_</font></td>
          <td align="left"><input type="text" id="userName" name="userName" required size="10" maxlength="20"></td>
        </tr>
        <tr>
          <td align="right"><label for="password_1">Password:</label></td>
          <td></td>
          <td align="left"><input type="password" id="password_1" name="password_1" required size="10"maxlength="20" ></td>
        </tr>
        <tr>
          <td align="right"><label for="password_2">Confirm Password:</label></td>
          <td></td>
          <td align="left"><input type="password" id="password_2" name="password_2"required size="10"maxlength="20"></td>
        </tr>
        <tr>
          <td align="right"><label for="email">Email:</label></td>
          <td></td>
          <td align="left"><input type="text" id="email" name="email" required size="10"></td>
        </tr>

        <tr>
          <td align="right"><label for="state">State:</label></td>
          <td></td>
          <td align="left"><select name="state" id="state" required>
          <!--  <option value="" selected="selected">Select a State</option>  -->
<!--<option value="AL">Alabama</option>
<option value="AK">Alaska</option>
<option value="AZ">Arizona</option>
<option value="AR">Arkansas</option>
<option value="CA">California</option>
<option value="CO">Colorado</option>
<option value="CT">Connecticut</option>
<option value="DE">Delaware</option>
<option value="DC">District Of Columbia</option>
<option value="FL">Florida</option>-->
<option value="GA">Georgia</option>
<!--<option value="HI">Hawaii</option>
<option value="ID">Idaho</option>
<option value="IL">Illinois</option>
<option value="IN">Indiana</option>
<option value="IA">Iowa</option>
<option value="KS">Kansas</option>
<option value="KY">Kentucky</option>
<option value="LA">Louisiana</option>
<option value="ME">Maine</option>
<option value="MD">Maryland</option>
<option value="MA">Massachusetts</option>
<option value="MI">Michigan</option>
<option value="MN">Minnesota</option>
<option value="MS">Mississippi</option>
<option value="MO">Missouri</option>
<option value="MT">Montana</option>
<option value="NE">Nebraska</option>
<option value="NV">Nevada</option>
<option value="NH">New Hampshire</option>
<option value="NJ">New Jersey</option>
<option value="NM">New Mexico</option>
<option value="NY">New York</option>
<option value="NC">North Carolina</option>
<option value="ND">North Dakota</option>
<option value="OH">Ohio</option>
<option value="OK">Oklahoma</option>
<option value="OR">Oregon</option>
<option value="PA">Pennsylvania</option>
<option value="RI">Rhode Island</option>
<option value="SC">South Carolina</option>
<option value="SD">South Dakota</option>
<option value="TN">Tennessee</option>
<option value="TX">Texas</option>
<option value="UT">Utah</option>
<option value="VT">Vermont</option>
<option value="VA">Virginia</option>
<option value="WA">Washington</option>
<option value="WV">West Virginia</option>
<option value="WI">Wisconsin</option>
<option value="WY">Wyoming</option>-->
                            </select></td>
        </tr>
        <?php $georgia = array(
          "Appling County",
          "Atkinson County",
          "Bacon County",
          "Baker County",
          "Baldwin County",
          "Banks County",
          "Barrow County",
          "Bartow County",
          "Ben Hill County",
          "Berrien County",
          "Bibb County",
          "Bleckley County",
          "Brantley County",
          "Brooks County",
          "Bryan County",
          "Bulloch County",
          "Burke County",
          "Butts County",
          "Calhoun County",
          "Camden County",
          "Candler County",
          "Carroll County",
          "Catoosa County",
          "Charlton County",
          "Chatham County",
          "Chattahoochee County",
          "Chattooga County",
          "Cherokee County",
          "Clarke County",
          "Clay County",
          "Clayton County",
          "Clinch County",
          "Cobb County",
          "Coffee County",
          "Colquitt County",
          "Columbia County",
          "Cook County",
          "Coweta County",
          "Crawford County",
          "Crisp County",
          "Dade County",
          "Dawson County",
          "Decatur County",
          "DeKalb County",
          "Dodge County",
          "Dooly County",
          "Dougherty County",
          "Douglas County",
          "Early County",
          "Echols County",
          "Effingham County",
          "Elbert County",
          "Emanuel County",
          "Evans County",
          "Fannin County",
          "Fayette County",
          "Floyd County",
          "Forsyth County",
          "Franklin County",
          "Fulton County",
          "Gilmer County",
          "Glascock County",
          "Glynn County",
          "Gordon County",
          "Grady County",
          "Greene County",
          "Gwinnett County",
          "Habersham County",
          "Hall County",
          "Hancock County",
          "Haralson County",
          "Harris County",
          "Hart County",
          "Heard County",
          "Henry County",
          "Houston County",
          "Irwin County",
          "Jackson County",
          "Jasper County",
          "Jeff Davis County",
          "Jefferson County",
          "Jenkins County",
          "Johnson County",
          "Jones County",
          "Lamar County",
          "Lanier County",
          "Laurens County",
          "Lee County",
          "Liberty County",
          "Lincoln County",
          "Long County",
          "Lowndes County",
          "Lumpkin County",
          "Macon County",
          "Madison County",
          "Marion County",
          "McDuffie County",
          "McIntosh County",
          "Meriwether County",
          "Miller County",
          "Mitchell County",
          "Monroe County",
          "Montgomery County",
          "Morgan County",
          "Murray County",
          "Muscogee County",
          "Newton County",
          "Oconee County",
          "Oglethorpe County",
          "Paulding County",
          "Peach County",
          "Pickens County",
          "Pierce County",
          "Pike County",
          "Polk County",
          "Pulaski County",
          "Putnam County",
          "Quitman County",
          "Rabun County",
          "Randolph County",
          "Richmond County",
          "Rockdale County",
          "Schley County",
          "Screven County",
          "Seminole County",
          "Spalding County",
          "Stephens County",
          "Stewart County",
          "Sumter County",
          "Talbot County",
          "Taliaferro County",
          "Tattnall County",
          "Taylor County",
          "Telfair County",
          "Terrell County",
          "Thomas County",
          "Tift County",
          "Toombs County",
          "Towns County",
          "Treutlen County",
          "Troup County",
          "Turner County",
          "Twiggs County",
          "Union County",
          "Upson County",
          "Walker County",
          "Walton County",
          "Ware County",
          "Warren County",
          "Washington County",
          "Wayne County",
          "Webster County",
          "Wheeler County",
          "White County",
          "Whitfield County",
          "Wilcox County",
          "Wilkes County",
          "Wilkinson County",
          "Worth County"
      );
      $state = $georgia;
?>

        <tr>
          <td align="right"><label for="county">County:</label></td>
          <td></td>
          <td align="left">
<!--<span id="precounty"></span><span style="display: none" id="county">-->

            <select name="county">

            <option value="" selected="selected">Select a County</option>
            <?php
                    foreach ($state as $counties){
                    echo "$counties <br>";
echo "<option value='$counties'>$counties</option>";


                  }
            ?>

</select>

<!--</span>-->
</td>
</tr>










        <tr>
          <td align="right"><label for="textNumber">Text Msg Number:</label></td>
          <td></td>
          <td align="left"><input type="phone" id="textNumber" name="textNumber" maxlength="10" size="10"></td>
        </tr>
        <tr>
          <td align="right"><label for="sport">Sport:</label></td>
          <td></td>
          <td align="left"><select name="sport" id="sport" required>
                              <!--<option value="" selected disabled> -- select an option -- </option>-->
                              <option value="softball">Softball</option>
                              <option value="baseball" disabled>Baseball </option>
                            </select></td>
        </tr>
        <tr>
          <td align="right"><label for="ageGroup">Age Group:</label></td>
          <td></td>
          <td align="left"><select name="ageGroup" id="ageGroup" required>
                        <!--      <option value="" selected disabled> -- select an option -- </option>-->
                              <option value="14" >14uu</option>
                              <option value="7" disabled>7u</option>
                              <option value="8" >8u</option>
                              <option value="9" disabled>9u</option>
                              <option value="10" >10u</option>
                              <option value="11" disabled>11u</option>
                              <option value="12" >12u</option>
                              <option value="13" disabled>13u</option>
                              <option value="14">14u</option>
                              <option value="15" disabled>15u</option>
                              <option value="16" >16u</option>
                              <option value="17" disabled>17u</option>
                              <option value="18" >18u</option>
                              <option value="20" >College</option>
                            </select></td>
        </tr>

      </table>


      <br><br>
    <input type="submit" name="submitRegister" value="Submit">
  </form>

  </div>
  <div class="bottom">
    <?php
      if(isset($_SESSION["emailError"])){
        echo "Email already in use....please re-register!";
        unset($_SESSION['emailError']);
      }
      echo "<br>";
      if(isset($_SESSION["teamNameError"])){
        echo "Team Name already in use....please re-register!";
        unset($_SESSION['teamNameError']);
      }
     ?>
  </div>
</div>

<!--<script>
$(document).ready(function(){
  //var end = this.value;
  $("#state").change(function(){

    $("#precounty").hide();
    $("#county").show();


  });
});
</script>-->





  </body>
</html>
